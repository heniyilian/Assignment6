
public class Pet {
	private int id;
	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	private int price;
	
	public Pet() {
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getEat() {
		return eat;
	}

	public String getDrink() {
		return drink;
	}

	public String getLive() {
		return live;
	}

	public String getHobby() {
		return hobby;
	}
	
	public int getPrice() {
		return price;
	}

	public void setId(int id) {
		this.id = id;
		price = (id/2) * 9 + (id/4) * 3 + 10 * (id/7 + 2);
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEat(String eat) {
		this.eat = eat;
	}

	public void setDrink(String drink) {
		this.drink = drink;
	}

	public void setLive(String live) {
		this.live = live;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	
	
}

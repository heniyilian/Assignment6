import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class GUI extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel lp,sp,mp,cp;
	static GUI gui;
	
	public static void main(String[] args) {
		gui = new GUI();
	}
	
	public GUI() {
		super("Pet Market");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(401, 300);
		
		lp = new LogPanel();
		sp = new SignPanel();
		mp = new MarketPanel();
		cp = new CartPanel();
		add(lp);
		
		setVisible(true);
	}
	
	public void toSign() {
		setSize(400, 300);
		remove(lp);
		add(sp);
		repaint();
	}
	
	public void toLog() {
		remove(sp);
		add(lp);
		repaint();
	}

	public void toMarket() {
		setSize(1300, 550);
		remove(lp);
		add(mp);
		repaint();
	}
	
	public void toCart() {
		setSize(500, 500);
		remove(mp);
		add(cp);
		repaint();
	}
	
	public void returnMarket() {
		setSize(1300, 550);
		remove(cp);
		add(mp);
		repaint();
	}
}

class LogPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel welLabel;
	private JLabel userLabel;
	private JTextField userText;
	private JLabel keyLabel;
	private JPasswordField keyText;
	private JButton logButton;
	private JButton signButton;
	
	public LogPanel() {
		setLayout(null);
		
		welLabel = new JLabel("Welcome to my pet market!");
		add(welLabel);
		welLabel.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		welLabel.setBounds(55, 30, 300, 30);
		
		userLabel = new JLabel("Username");
		add(userLabel);
		userLabel.setBounds(70, 100, 60, 25);
		
		userText = new JTextField();
		add(userText);
		userText.setBounds(150, 100, 150, 25);
		
		keyLabel = new JLabel("Password");
		add(keyLabel);
		keyLabel.setBounds(70, 150, 60, 25);
		
		keyText = new JPasswordField();
		add(keyText);
		keyText.setBounds(150, 150, 150, 25);
		
		logButton = new JButton("Log in");
		add(logButton);
		logButton.setBounds(100, 200, 80, 40);
		logButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}
				try {
					Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
					PreparedStatement ps = con.prepareStatement("SELECT * FROM 2014301060003_user;");
					ResultSet rs = ps.executeQuery();
					
					// log in
					
					rs.close();
					ps.close();
					con.close();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
				GUI.gui.toMarket();
			}
		});
		
		signButton = new JButton("Sign up");
		add(signButton);
		signButton.setBounds(200, 200, 80, 40);
		signButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.gui.toSign();
			}
		});
	}
}

class SignPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel welLabel;
	private JLabel userLabel;
	private JTextField userText;
	private JLabel keyLabel;
	private JPasswordField keyText;
	private JButton signButton;
	private JButton returnButton;
	
	public SignPanel() {
		setLayout(null);
		
		welLabel = new JLabel("Sign up with an account!");
		add(welLabel);
		welLabel.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		welLabel.setBounds(75, 30, 300, 30);
		
		userLabel = new JLabel("Username");
		add(userLabel);
		userLabel.setBounds(70, 100, 60, 25);
		
		userText = new JTextField();
		add(userText);
		userText.setBounds(150, 100, 150, 25);
		
		keyLabel = new JLabel("Password");
		add(keyLabel);
		keyLabel.setBounds(70, 150, 60, 25);
		
		keyText = new JPasswordField();
		add(keyText);
		keyText.setBounds(150, 150, 150, 25);
		
		signButton = new JButton("Sign up");
		add(signButton);
		signButton.setBounds(100, 200, 80, 40);
		signButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}
				try {
					Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
					PreparedStatement ps = con.prepareStatement("SELECT * FROM 2014301060003_user;");
					ResultSet rs = ps.executeQuery();
					
					//sign up
					
					rs.close();
					ps.close();
					con.close();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
				GUI.gui.toLog();
			}
		});
		
		returnButton = new JButton("Return");
		add(returnButton);
		returnButton.setBounds(200, 200, 80, 40);
		returnButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.gui.toLog();
			}
		});
	}
}

class MarketPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int sx,sy,xSpace,ySpace,width,hight;
	private int petNumber;
	private Pet pet[];
	private JLabel infoLabel[];
	private JLabel petInfo[][];
	private JButton buyButton[];
	private JButton cartButton;
	
	public MarketPanel() {
		setLayout(null);
		
		sx = 20;
		sy = 70;
		hight = 25;
		width = 150;
		xSpace = 160;
		ySpace = 35;
		petNumber = 12;
		pet = new Pet[petNumber];
		buyButton = new JButton[petNumber];
		infoLabel = new JLabel[7];
		petInfo = new JLabel[petNumber][7];
		
		infoLabel[0] = new JLabel("ID");
		infoLabel[1] = new JLabel("Name");
		infoLabel[2] = new JLabel("Eat");
		infoLabel[3] = new JLabel("Drink");
		infoLabel[4] = new JLabel("Live");
		infoLabel[5] = new JLabel("Hobby");
		infoLabel[6] = new JLabel("Price");
		
		for (int i = 0; i < 7; i++) {
			infoLabel[i].setBounds(sx + xSpace * i, 20, width, hight);
			add(infoLabel[i]);
		}
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			PreparedStatement ps = con.prepareStatement("SELECT * FROM 2014301060003_pet;");
			ResultSet rs = ps.executeQuery();
			
			for (int i = 0; i < petNumber; i++) {
				pet[i] = new Pet();
				
				rs.next();
				pet[i].setId(i+1);
				pet[i].setName(rs.getString(2).toLowerCase());
				pet[i].setEat(rs.getString(3).toLowerCase());
				pet[i].setDrink(rs.getString(4).toLowerCase());
				pet[i].setLive(rs.getString(5).toLowerCase());
				pet[i].setHobby(rs.getString(6).toLowerCase());
				
				petInfo[i][0] = new JLabel("" + pet[i].getId());
				petInfo[i][1] = new JLabel(pet[i].getName());
				petInfo[i][2] = new JLabel(pet[i].getEat());
				petInfo[i][3] = new JLabel(pet[i].getDrink());
				petInfo[i][4] = new JLabel(pet[i].getLive());
				petInfo[i][5] = new JLabel(pet[i].getHobby());
				petInfo[i][6] = new JLabel("" + pet[i].getPrice());
				
				for (int j = 0; j < 7; j++) {
					petInfo[i][j].setBounds(sx + xSpace * j, sy + ySpace * i, width, hight);
					add(petInfo[i][j]);
				}
				
				buyButton[i] = new JButton("Buy");
				buyButton[i].setBounds(sx + xSpace * 7, sy + ySpace * i, 60, 30);
				buyButton[i].addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// add to cart
					}
				});
				add(buyButton[i]);
			}
			
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		cartButton = new JButton("Cart");
		cartButton.setBounds(sx + xSpace * 7, 20, 60, 30);
		cartButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.gui.toCart();
			}
		});
		add(cartButton);
	}
}

class CartPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton marketButton;
	private JButton payButton;
	
	public CartPanel() {
		setLayout(null);
		
		payButton = new JButton("Pay");
		payButton.setBounds(380, 320, 80, 30);
		payButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// pay
			}
		});
		add(payButton);
		
		marketButton = new JButton("Return");
		marketButton.setBounds(380, 20, 80, 30);
		marketButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.gui.returnMarket();
			}
		});
		add(marketButton);
	}
}